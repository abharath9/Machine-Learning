%function to implement logisticregrssion with two variables
function [theta,J]=logistic_regression2a_test()
%load the dataset
dataset=load('RegressionData.csv');
%shuffle the data
%dataset=dataset(randperm(length(dataset)),:);
%load the input train dataset
x_train = dataset(:, 2);
x1_train = dataset(:, 4);
%load the output labels
y_train = dataset(:, 1);
% choose the training dataset input
x=x_train(1:421,1);
x1=x1_train(1:421,1);
% choose the training dataset output labels
y=y_train(1:421,1);
% choose the testing dataset input
x_test=x_train(631:842,1);
x1_test=x1_train(631:842,1);
% choose the testing dataset output
y_test=y_train(631:842,1);
%initialize theta values
theta=[0 0 0];
m=length(x);
%plot the input vs labels
figure();
scatter3(x,x1,y,'o');
ylabel('ACT');
xlabel('HSGPA');
zlabel('Retained');
%append ones vector to the input
x = [ones(m, 1), x,x1];
%initilize learning rate
alpha=0.002;
%number of iterations
iter_num=15000;
threshold=0.000001;
%call gradient descent
[theta,J,I]=gradient_descent(x,y,theta,alpha,iter_num,threshold);
%append ones vector to the testing data
x_test = [ones(length(x_test), 1), x_test,x1_test];
z=theta*x_test';
%calcualte the sigmoid function
h=1./(ones(1,length(x_test))+exp(-z));
%assign the label as 1 for the input sigmoid output is greater than 0.5 and
%assign to 0 otherwise
T(h>=.5) = 1;
T(h<.5) = 0;
display(size(x_test));
%plot the predicted labels
hold on % Plot new data without clearing old plot
scatter3(x_test(:,2),x_test(:,3),T,'g+');
legend('Training data', 'Logistic regression')
%calculate the confusion matrix
C = confusionmat(y_test',T);
%extract true positives, true negatives, false postive sna dfalse negatives
%from confusion matrix
display(C);
TP=C(1,1);
FN=C(1,2);
FP=C(2,1);
TN=C(2,2);
%calculate the precision and recalss for class0 and class1
precision1=TP/(TP+FP);
precision2=TN/(FN+TN);
recall1=TP/(TP+FN);
recall2=TN/(FP+TN);
%Calculate F-measures for each class
F_Score1=2*TP/((2*TP)+FP+FN);
F_Score2=2*TN/((2*TN)+FP+FN);
TPR=TP/(TP+FN);
FPR=1-(TN/(FP+TN));
display(F_Score1);
display(F_Score2);
figure();
%plot the graph between cost and iterations
plot(I,J);
ylabel('Cost');
xlabel('Iterations');
%calculate the area under curve value
[P,Q,S,AUC] = perfcurve(y_test,T,1);
display(AUC);
figure();
%plot area under curve
plot(P,Q);
ylabel('True positive rate');
xlabel('False positive rate');
%display(I);
%display(x1);
end
%function to gradient descent
function [theta,J,I]=gradient_descent(x,y,theta,alpha,iter_num,threshold)
m=length(x);
cost_temp=0;
%change the theta values by iterating through number of iterations
for i=1:iter_num
    z=theta*x';
    h=1./(ones(1,length(x))+exp(-z));
    temp0=theta(1)-alpha * ((h-y')*x(:,1)/m);
    temp1=theta(2)-alpha * ((h-y')*x(:,2)/m);
    temp2=theta(3)-alpha * ((h-y')*x(:,3)/m);
    theta=[temp0 temp1 temp2];
    J(i)=cost(x,y,theta);
    I(i)=i;
    %break if threshodl value has reached
    if(abs(cost_temp-J(i))<=threshold)
        break
    end
    cost_temp=J(i);
end
end
%function to cost
function [J]=cost(x,y,theta)
z=theta*x';
%sigmoid function
sigmoid=1./(ones(1,length(x))+exp(-z));
positive=y'*(log(sigmoid))';
negative=(ones(1,length(x))-y')*(log(ones(1,length(x))-sigmoid))';
%squared error
squared_error=positive+negative;
%final cost
J=-sum(squared_error)/(length(x));
end
