% function to implement Logistic regression with one variable
function [theta,J]=logistic_regression1_test()
%load the dataset
dataset=load('RegressionData.csv');
%shuffle the data
dataset=dataset(randperm(length(dataset)),:);
%load the input train dataset
x_train = dataset(:, 4);
%load the output labels
y_train = dataset(:, 1);
% choose the training dataset input
x=x_train(1:421,1);
% choose the training dataset output labels
y=y_train(1:421,1);
% choose the testing dataset input
x_test=x_train(590:842,1);
% choose the testing dataset input
y_test=y_train(590:842,1);
%initialize theta values
theta=[1 1];
%get the length of input matrix
m=length(x);
%plot the input vs labels
figure();
plot(x,y,'o');
ylabel('Retained');
xlabel('HSGPA');
%append ones vector to the input
x = [ones(m, 1), x];
%initilize learning rate
alpha=0.25;
%number of iterations
iter_num=15000;
%choose a threshold value
threshold=0.000001;
%call gradient descent
[theta,J,I]=gradient_descent(x,y,theta,alpha,iter_num,threshold);
%append ones vector to the testing data
x_test = [ones(length(x_test), 1), x_test];
z=theta*x_test';
%calcualte the sigmoid function
h=1./(ones(1,length(x_test))+exp(-z));
display(size(h));
%assign the label as 1 for the input sigmoid output is greater than 0.5 and
%assign to 0 otherwise
T(h>=.5) = 1;
T(h<.5) = 0;
%plot the predicted labels
figure();
plot(x_test(:,2),y_test,'o');
hold on % Plot new data without clearing old plot
plot(x_test(:,2),T','g+');
legend('Training data', 'Logistic regression')
%calculate the confusion matrix
C = confusionmat(y_test',T);
display(C);
%extract true positives, true negatives, false postive sna dfalse negatives
%from confusion matrix
TP=C(1,1);
FN=C(1,2);
FP=C(2,1);
TN=C(2,2);
%calculate the precision and recalss for class0 and class1
precision1=TP/(TP+FP);
precision2=TN/(FN+TN);
recall1=TP/(TP+FN);
recall2=TN/(FP+TN);
%Calculate F-measures for each class
F_Score1=2*TP/((2*TP)+FP+FN);
F_Score2=2*TN/((2*TN)+FP+FN);
TPR=TP/(TP+FN);
FPR=1-(TN/(FP+TN));
display(F_Score1);
display(F_Score2);
%plot the graph between cost and iterations
figure();
plot(I,J);
ylabel('Cost');
xlabel('Iterations');
%calculate the area under curve value
[P,Q,S,AUC] = perfcurve(y_test,T',1);
display(AUC);
figure();
%plot area under curve
plot(P,Q);
ylabel('True positive rate');
xlabel('False positive rate');
%plot sigmoid function
figure();
plot(z,h,'o');
ylabel('g(z)');
xlabel('z');
end
%calcualte gradiengt descent
function [theta,J,I]=gradient_descent(x,y,theta,alpha,iter_num,threshold)
%J=zeros(iter_num,1);
m=length(y);
cost_temp=0;
%iterate through number of iteratins and change the theta values
for i=1:iter_num
    z=theta*x';
    h=1./(ones(1,length(x))+exp(-z));
    temp0=theta(1)-alpha * (((h-y')*x(:,1))/m);
    temp1=theta(2)-alpha * ((h-y')*x(:,2)/m);
    theta=[temp0 temp1];
    J(i)=cost(x,y,theta);
    I(i)=i;
    %break the loop if it has reached the thershold value
    if(abs(cost_temp-J(i))<=threshold)
        break
    end
    cost_temp=J(i);
end
end
%cost function
function [J]=cost(x,y,theta)
z=theta*x';
%sigmoid fucntion
sigmoid=1./(ones(1,length(x))+exp(-z));
positive=y'*(log(sigmoid))';
negative=(ones(1,length(x))-y')*(log(ones(1,length(x))-sigmoid))';
%squared error
squared_error=positive+negative;
%final cost
J=-squared_error/(length(x));
end
