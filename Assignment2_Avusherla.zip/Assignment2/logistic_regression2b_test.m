function [theta,J]=logistic_regression2b_test()
%load and shuffle the datset
dataset=load('RegressionData.csv');
dataset=dataset(randperm(length(dataset)),:);
%ecxtract the input and output labels from the dataset
x_train = dataset(:, 4);
x1_train = dataset(:, 2);
x2_train = dataset(:, 3);
y_train = dataset(:, 1);
%select the training and testing datset sizes
x=x_train(1:674,1);
x1=x1_train(1:674,1);
x2=x2_train(1:674,1);
y=y_train(1:674,1);
x_test=x_train(675:842,1);
x1_test=x1_train(675:842,1);
x2_test=x2_train(675:842,1);
y_test=y_train(675:842,1);
%select initial theta values
theta=[0 0 0 0];
m=length(x);
x = [ones(m, 1), x,x1,x2];
%initialize the learning rate, iterationsn and threshold values
alpha=0.003;
iter_num=15000;
threshold=0.000001;
%call the gradient descent funstion
[theta,J,I]=gradient_descent(x,y,theta,alpha,iter_num,threshold);
%apply the sigmoid function
x_test = [ones(length(x_test), 1), x_test,x1_test,x2_test];
z=theta*x_test';
h=1./(ones(1,length(x_test))+exp(-z));
%assign the label as 1 for the input sigmoid output is greater than 0.5 and
%assign to 0 otherwise
T(h>=.5) = 1;
T(h<.5) = 0;
display(size(x));
%calculate the confusion matrix
C = confusionmat(y_test',T);
%extract true positives, true negatives, false postive sna dfalse negatives
%from confusion matrix
display(C);
TP=C(1,1);
FN=C(1,2);
FP=C(2,1);
TN=C(2,2);
%calculate the precision and recalss for class0 and class1
precision1=TP/(TP+FP);
precision2=TN/(FN+TN);
recall1=TP/(TP+FN);
recall2=TN/(FP+TN);
F_Score1=2*TP/((2*TP)+FP+FN);
F_Score2=2*TN/((2*TN)+FP+FN);
TPR=TP/(TP+FN);
FPR=1-(TN/(FP+TN));
display(F_Score1);
display(F_Score2);
figure();
%plot the graph between cost and iterations
plot(I,J);
ylabel('Cost');
xlabel('Iterations');
[P,Q,S,AUC] = perfcurve(y_test',T,1);
display(AUC);
%calculate the area under curve value
figure();
plot(P,Q);
ylabel('True positive rate');
xlabel('False positive rate');
end
%function to gradient descent
function [theta,J,I]=gradient_descent(x,y,theta,alpha,iter_num,threshold)
%J=zeros(iter_num,1);
m=length(y);
cost_temp=0;
%change the theta values by iterating through number of iterations
for i=1:iter_num
    z=theta*x';
    h=1./(ones(1,length(x))+exp(-z));
    temp0=theta(1)-alpha * ((h-y')*x(:,1))/m;
    temp1=theta(2)-alpha * ((h-y')*x(:,2)/m);
    temp2=theta(3)-alpha * ((h-y')*x(:,3)/m);
    temp3=theta(4)-alpha * ((h-y')*x(:,4)/m);
    theta=[temp0 temp1 temp2 temp3];
    J(i)=cost(x,y,theta);
    I(i)=i;
    %break if threshodl value has reached
    if(abs(cost_temp-J(i))<=threshold)
        break
    end
    cost_temp=J(i);
end
end
%function to cost
function [J]=cost(x,y,theta)
%sigmoid function
z=theta*x';
sigmoid=1./(ones(1,length(x))+exp(-z));
positive=y'*(log(sigmoid))';
negative=(ones(1,length(x))-y')*(log(ones(1,length(x))-sigmoid))';
%squared error
squared_error=positive+negative;
%final cost
J=-sum(squared_error)/(length(x));
end
