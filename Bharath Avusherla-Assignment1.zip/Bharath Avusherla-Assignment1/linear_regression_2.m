%Function to implement quadratic linear regression with one variable algorithm
function [theta,J]=linear_regression_2()
%load the input features and output labels to the variables
x=load('x-80.dat');
y=load('y-80.dat');
%assign initial theta values
theta=[0 0 0];
%plot the input features and output labels
figure();
plot(x, y, 'o');
ylabel('ACT');
xlabel('HSGPA');
%calculate the length of input vector
m=length(x);
%add one valued column vector to x
x = [ones(m, 1),x,power(x,2)];
%initialize learning rate as 0.01
alpha=0.01;
%initialize number of iterations
iter_num=1500;
%initialize threshold value
threshold=0.01;
%call gradient descent value
[theta,J]=gradient_descent(x,y,theta,alpha,iter_num,threshold);
%plot the predicted labels to the existing graph without clearing
hold on % Plot new data without clearing old plot
plot(x(:,2), x*theta','gx');
legend('Training data', 'Quadratic regression')
end
%gradient descent
function [theta,J]=gradient_descent(x,y,theta,alpha,iter_num,threshold)
m=length(y);
%initializeintial cost to zero
cost_temp=0;
%calculate the minimum cost by iterating through the number of iterations
for i=1:iter_num
    %calculate the predicted labels
    h=theta*x';
    %normalize the theta values
    temp0=theta(1)-alpha * ((h-y')*x(:,1))/m;
    temp1=theta(2)-alpha * ((h-y')*x(:,2))/m;
    temp2=theta(3)-alpha * ((h-y')*x(:,3))/m;
    %assign new theta values
    theta=[temp0 temp1 temp2];
    %calculate the cost
    J(i)=cost(x,y,theta);
    %check if cost diffrenece is less than or equal to the threshold value
    if(abs(cost_temp-J(i))<=threshold)
        break
    end
    %store new cost to the temporary variable
    cost_temp=J(i);
end
end
%cost
function [J]=cost(x,y,theta)
%predict the output labels
predictions=theta*x';
squared_error=power((predictions - y'),2);
%calculate the cost
J=sum(squared_error)/(2*length(y));
end