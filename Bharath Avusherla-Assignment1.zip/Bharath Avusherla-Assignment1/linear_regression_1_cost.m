%Function to calculate the cost in linear regression with one variable algorithm
function [theta]=linear_regression_1_cost()
%load the input features and outputlabels to the variables
x=load('x.dat');
y=load('y.dat');
%initialize the theta values to [0 0]
theta=[0 0];
%get the length of input vector
m=length(x);
x = [ones(m, 1), x];
%Initialize the learning rate
alpha=0.01;
%initialize the number of iterations as 1500
iter_num=1500;
%assign the 0.01 to the threshold variable
threshold=0.01;
%Call the gradient_descent function
[theta,J,I]=gradient_descent(x,y,theta,alpha,iter_num,threshold);
%plot the graph between number of iterations and cost
figure();
plot(I,J,'bx');
ylabel('Cost')
xlabel('Iterations')
end
%Gradient Descent
function [theta,J,I]=gradient_descent(x,y,theta,alpha,iter_num,threshold)
m=length(y);
%assign initial cost to zero
cost_temp=0;
%calculate the minimum cost by iterating through the number ofiterations
for i=1:iter_num
    %hypothesis ouput
    h=theta*x';
    %alter the existing theta values
    temp0=theta(1)-alpha * ((h-y')*x(:,1))/m;
    temp1=theta(2)-alpha * ((h-y')*x(:,2))/m;
    theta=[temp0 temp1];
    I(i)=i;
    %get the cost or error rate using cost function
    J(i)=cost(x,y,theta);
    %check whether the cost diffrence less than the threshold
    if(abs(cost_temp-J(i))<=threshold)
        break
    end
    %add new cost value to the temporary variable
    cost_temp=J(i);
end
end
%Cost function
function [J]=cost(x,y,theta)
%get the predicted values
predictions=theta*x';
%calculate the squared error
squared_error=power((predictions - y'),2);
%calculate the cost
J=sum(squared_error)/(2*length(y));
end