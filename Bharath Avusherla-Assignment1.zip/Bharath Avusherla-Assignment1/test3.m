theta=[21.3211    9.6995   -0.1858];
x=load('x-20.dat');
y=load('y-20.dat');
m=length(x);
x = [ones(m, 1),x,power(x,2)];
yy=theta*x';
figure();
plot(x,y,'bo',x,yy,'go')
ylabel('ACT')
xlabel('HSGPA')