%Function to implement linear regression with one variable algorithm
function [theta,J]=linear_regression_1()
%load the input features and outputlabels to the variables
x=load('x-80.dat');
y=load('y-80.dat');
%initialize the theta values to [0 0]
theta=[0 0];
%plot the input features and output labels on the graph
figure();
plot(x, y, 'o');
%add the x-axis, y-axis names on the graph
ylabel('ACT')
xlabel('HSGPA')
%get the length of input vector
m=length(x);
%add one valued column vector to the x
x = [ones(m, 1), x];
%Initialize the learning rate
alpha=0.07;
%initialize the number of iterations as 1500
iter_num=1500;
%assign the 0.01 to the threshold variable
threshold=0.01;
%Call the gradient_descent function
[theta,J]=gradient_descent(x,y,theta,alpha,iter_num,threshold);
%plot the predicted values on the graph without clearing
hold on % Plot new data without clearing old plot
plot(x(:,2), x*theta', 'r-');
legend('Testing data', 'Linear regression')
end
%Gradient Descent function
function [theta,J]=gradient_descent(x,y,theta,alpha,iter_num,threshold)
%get the length of input vector
m=length(y);
%assign initial cost to zero
cost_temp=0;
%calculate the minimum cost by iterating through the number ofiterations
for i=1:iter_num
    %hypothesis ouput
    h=theta*x';
    %alter the existing theta values
    temp0=theta(1)-alpha * ((h-y')*x(:,1))/m;
    temp1=theta(2)-alpha * ((h-y')*x(:,2))/m;
    %assign new theta values to theta variable
    theta=[temp0 temp1];
    %get the cost or error rate using cost function
    J(i)=cost(x,y,theta);
    %check whether the cost diffrence less than the threshold
    if(abs(cost_temp-J(i))<=threshold)
        break
    end
    %add new cost value to the temporary variable
    cost_temp=J(i);
end
end
%Cost function
function [J]=cost(x,y,theta)
%get the predicted values
predictions=theta*x';
%calculate the squared error
squared_error=power((predictions - y'),2);
%calculate the cost
J=sum(squared_error)/(2*length(y));
end