theta=[21.3031    9.0807    0.2242];
x=load('x-gender-10.txt');
y=load('y-10.txt');
m=length(x);
x = [ones(m, 1),x];
yy=theta*x';
figure();
plot(x,y,'bo',x,yy,'go')
ylabel('ACT')
xlabel('HSGPA')