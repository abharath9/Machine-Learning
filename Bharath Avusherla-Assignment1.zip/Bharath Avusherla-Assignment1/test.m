theta=[25.9235    7.3883];
x=load('x-20.dat');
y=load('y-20.dat');
x = [ones(length(x), 1), x];
yy=theta*x';
figure();
plot(x,y,'bo',x,yy,'go')
ylabel('ACT')
xlabel('HSGPA')

